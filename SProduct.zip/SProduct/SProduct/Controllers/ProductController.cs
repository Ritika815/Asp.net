﻿using Microsoft.AspNetCore.Mvc;
using SProduct.Models;

namespace SProduct.Controllers
{
    public class ProductController : Controller
    {
        private static List<Product> products = new List<Product>
        {
            new Product{Id=1,Name="Pen",Price=35},
            new Product{Id=2,Name="Pencil",Price=5},
            new Product{Id=3,Name="Eraser",Price=5}
        };
        public IActionResult Index()
        {
            return View(products);
        }
    }
}
